# Homework: Javascript X - Ejercicios Extras

## Instrucciones
---
1. En esta homework encontrarás ejercicios extras, para que sigas afianzando todo lo aprendido hasta el momento.


2. Desde la carpeta `Prep` en la carpeta donde clonaste el repo, ingresa el comando `npm test JSX.test.js` para correr los tests automatizados. Al principio, todos los tests estarán fallados/rotos. Encontrarás las funciones para hacer pasar los tests en el archivo `homework.js`.

