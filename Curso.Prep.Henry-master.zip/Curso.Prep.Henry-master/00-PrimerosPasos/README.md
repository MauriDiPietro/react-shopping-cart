<img  src='../logo.png' height='70px'>
<table width="100%" style='table-layout:fixed;'>
  <tr>
    <td>
      <a href="https://airtable.com/shrSzEYT4idEFGB8d?prefill_clase=00-PrimerosPasos">
        <img src="https://static.thenounproject.com/png/204643-200.png" width="100"/>
        <br>
        Hacé click acá para dejar tu feedback sobre esta clase.
      </a>
    </td>
  </tr>
</table>

## Primeros Pasos

### Preparando tu compu:

Acá vas a encontrar todo lo que necesitas para arrancar el Curso de Preparación:

* [Editor de Texto](./editorTexto.md)
* [Github](./github.md)
* [Git](./git.md)
* [Instalar Node](./node.md)

### Instructivo de Primeros Pasos:

<iframe src="https://player.vimeo.com/video/486478241" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe> 


> **Nota**: Wanda menciona un mail con la invitacion al repo, ahora el repo es público, por lo tanto *no es necesario ese email*. Se puede acceder en este [link](https://github.com/atralice/Curso.Prep.Henry).
